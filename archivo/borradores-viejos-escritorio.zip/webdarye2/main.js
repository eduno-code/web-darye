// ===== MENÚ MÓVIL CON MEJORAS UX =====
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');

// Función para abrir/cerrar menú
function toggleMenu() {
    const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', !isExpanded);
    navMenu.classList.toggle('active');

    // Animación del botón hamburguesa
    const spans = menuToggle.querySelectorAll('span');
    if (!isExpanded) {
        spans[0].style.transform = 'rotate(45deg) translate(6px, 6px)';
        spans[1].style.opacity = '0';
        spans[1].style.transform = 'translateX(-10px)';
        spans[2].style.transform = 'rotate(-45deg) translate(6px, -6px)';

        // Prevenir scroll cuando el menú está abierto
        document.body.style.overflow = 'hidden';
    } else {
        spans[0].style.transform = 'none';
        spans[1].style.opacity = '1';
        spans[1].style.transform = 'none';
        spans[2].style.transform = 'none';

        // Restaurar scroll
        document.body.style.overflow = '';
    }
}

if (menuToggle) {
    menuToggle.addEventListener('click', toggleMenu);
}

// Cerrar menú al hacer clic en un enlace
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        if (navMenu && navMenu.classList.contains('active')) {
            toggleMenu();
        }
    });
});

// ===== CARRUSEL DE TESTIMONIOS =====
const track = document.getElementById('testimonialsTrack');
const dotsContainer = document.getElementById('testimonialDots');

if (track && dotsContainer) {
    const slides = Array.from(track.children);
    let currentIndex = 0;
    let autoplayInterval;
    const AUTOPLAY_MS = 5000;

    // Crear los puntos de navegación dinámicamente
    slides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.classList.add('dot');
        dot.setAttribute('aria-label', `Ir al testimonio ${i + 1}`);
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
    });

    const dots = Array.from(dotsContainer.children);

    function goToSlide(index) {
        currentIndex = (index + slides.length) % slides.length;
        track.style.transform = `translateX(-${currentIndex * 100}%)`;
        dots.forEach(d => d.classList.remove('active'));
        dots[currentIndex].classList.add('active');
    }

    function nextSlide() {
        goToSlide(currentIndex + 1);
    }

    function startAutoplay() {
        autoplayInterval = setInterval(nextSlide, AUTOPLAY_MS);
    }

    function stopAutoplay() {
        clearInterval(autoplayInterval);
    }

    // Pausar al pasar el mouse, reanudar al salir
    const slider = track.closest('.testimonials-slider');
    slider.addEventListener('mouseenter', stopAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);

    startAutoplay();
}
